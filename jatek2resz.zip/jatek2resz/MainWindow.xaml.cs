﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace jatek2resz
{
    public partial class MainWindow : Window
    {
        private Character player;
        private Character enemy;
        private Random random = new Random();

        public MainWindow()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            player = new Character("Hős", 10, 5, 3, 2);
            enemy = Character.GenerateRandomEnemy();
            UpdateUI();
        }

        private void MeleeAttack_Click(object sender, RoutedEventArgs e)
        {
            PerformBattleRound("melee");
        }

        private void MagicAttack_Click(object sender, RoutedEventArgs e)
        {
            PerformBattleRound("magic");
        }

        private void PerformBattleRound(string attackType)
        {
            int playerRoll = RollDice(20);
            int enemyRoll = RollDice(20);
            int playerDamage = CalculateDamage(player, enemy, playerRoll, attackType);
            int enemyDamage = CalculateDamage(enemy, player, enemyRoll, "melee");

            enemy.Health -= playerDamage;
            player.Health -= enemyDamage;

            CheckBattleOutcome();
            UpdateUI();
        }

        private int CalculateDamage(Character attacker, Character defender, int roll, string attackType)
        {
            int baseDamage = attacker.Attack + roll;
            if (attackType == "magic")
            {
                baseDamage += 5; // Mágia erősebb, de lehetne mana rendszer is
            }
            return Math.Max(0, baseDamage - defender.Defense);
        }

        private void CheckBattleOutcome()
        {
            if (enemy.Health <= 0)
            {
                MessageBox.Show("Győztél!");
                player.GainXP(10);
                enemy = Character.GenerateRandomEnemy();
                player.Health = 100;
            }
            else if (player.Health <= 0)
            {
                MessageBox.Show("Vesztettél!");
                player.Health = 100;
            }
        }

        private void UpdateUI()
        {
            PlayerStats.Text = player.ToString();
            EnemyStats.Text = enemy.ToString();
            PlayerHealthBar.Value = player.Health;
            EnemyHealthBar.Value = enemy.Health;
        }

        private int RollDice(int sides)
        {
            return random.Next(1, sides + 1);
        }
    }

    public class Character
    {
        public string Name { get; set; }
        public int Attack { get; set; }
        public int Defense { get; set; }
        public int Health { get; set; } = 100;
        public int XP { get; set; }

        public Character(string name, int attack, int defense, int health, int xp)
        {
            Name = name;
            Attack = attack;
            Defense = defense;
            Health = health;
            XP = xp;
        }

        public static Character GenerateRandomEnemy()
        {
            Random rand = new Random();
            return new Character("Ellenfél", rand.Next(5, 15), rand.Next(3, 10), 100, 0);
        }

        public void GainXP(int amount)
        {
            XP += amount;
            if (XP >= 50) { LevelUp(); }
        }

        private void LevelUp()
        {
            XP = 0;
            Attack += 2;
            Defense += 1;
            MessageBox.Show("Szintet léptél!");
        }

        public override string ToString()
        {
            return $"{Name} - Támadás: {Attack}, Védekezés: {Defense}, Élet: {Health}, XP: {XP}";
        }
    }
}
