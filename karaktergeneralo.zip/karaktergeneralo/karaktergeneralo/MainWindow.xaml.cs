﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;

namespace karaktergeneralo
{
    public partial class MainWindow : Window
    {
        private List<string> fajok = new List<string> { "Ember", "Elf", "Törpe", "Ork" };
        private List<string> kasztok = new List<string> { "Harcos", "Varázsló", "Íjász" };
        private Dictionary<string, int> tulajdonsagok;
        private int eloszthatoPontok = 10;

        public MainWindow()
        {
            InitializeComponent();
            cmbFaj.ItemsSource = fajok;
            cmbKaszt.ItemsSource = kasztok;
            InitTulajdonsagok();
        }

        private void InitTulajdonsagok()
        {
            tulajdonsagok = new Dictionary<string, int>
            {
                { "Strength", 5 },
                { "Dexterity", 5 },
                { "Vitality", 5 },
                { "Magic", 5 }
            };
            UpdateTulajdonsagok();
        }

        private void UpdateTulajdonsagok()
        {
            lblStrength.Text = "Strength: " + tulajdonsagok["Strength"];
            lblDexterity.Text = "Dexterity: " + tulajdonsagok["Dexterity"];
            lblVitality.Text = "Vitality: " + tulajdonsagok["Vitality"];
            lblMagic.Text = "Magic: " + tulajdonsagok["Magic"];
            lblEloszthato.Text = "Elosztható pontok: " + eloszthatoPontok;
        }

        private void BtnPlus_Click(object sender, RoutedEventArgs e)
        {
            if (eloszthatoPontok > 0)
            {
                string key = (sender as FrameworkElement).Tag.ToString();
                tulajdonsagok[key]++;
                eloszthatoPontok--;
                UpdateTulajdonsagok();
            }
        }

        private void BtnMinus_Click(object sender, RoutedEventArgs e)
        {
            string key = (sender as FrameworkElement).Tag.ToString();
            if (tulajdonsagok[key] > 0)
            {
                tulajdonsagok[key]--;
                eloszthatoPontok++;
                UpdateTulajdonsagok();
            }
        }

        private void BtnGenerateName_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists("nevek.txt"))
            {
                string[] nevek = File.ReadAllLines("nevek.txt");
                if (nevek.Length > 0)
                {
                    Random rand = new Random();
                    txtNev.Text = nevek[rand.Next(nevek.Length)];
                }
            }
            else
            {
                MessageBox.Show("A nevek.txt fájl nem található!");
            }
        }

        private void BtnSaveCharacter_Click(object sender, RoutedEventArgs e)
        {
            string karakterAdatok = $"Név: {txtNev.Text}, Faj: {cmbFaj.SelectedItem}, Kaszt: {cmbKaszt.SelectedItem}, " +
                                    $"Strength: {tulajdonsagok["Strength"]}, Dexterity: {tulajdonsagok["Dexterity"]}, " +
                                    $"Vitality: {tulajdonsagok["Vitality"]}, Magic: {tulajdonsagok["Magic"]}";

            File.AppendAllText("karakterek.txt", karakterAdatok + Environment.NewLine);
            MessageBox.Show("Karakter elmentve!");
        }
    }
}